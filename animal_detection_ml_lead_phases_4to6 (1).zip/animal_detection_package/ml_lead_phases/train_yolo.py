"""
train_yolo.py

PHASE 6: YOLO Training
Project: AI-Powered Intelligent Animal Detection, Identification & Smart Monitoring System
Role: ML Lead

Purpose
-------
Fine-tunes a pretrained YOLOv8n model on the custom dataset organized in
Phase 4/annotated in Phase 5, so it learns species like pig, goat, buffalo,
camel, tiger, lion, leopard, monkey, deer, snake that generic COCO weights
never saw.

Colab Free Tier survival strategy
----------------------------------
Colab free sessions disconnect unpredictably (idle timeout, 12hr cap, etc.).
This script:
    1. Saves every checkpoint to Google Drive (survives disconnects)
    2. Automatically resumes from the last checkpoint if one exists
    3. Uses early stopping (patience) so training doesn't run longer than needed
    4. Uses YOLOv8n (nano) - the smallest/fastest variant, fits free-tier
       GPU memory (T4 ~15GB, but Colab free tier often gives less) and even
       runs (slowly) on CPU as a fallback.

Usage (in Google Colab):
    from google.colab import drive
    drive.mount('/content/drive')

    !pip install ultralytics --quiet

    python train_yolo.py \
        --data /content/drive/MyDrive/animal_detection/data.yaml \
        --project /content/drive/MyDrive/animal_detection/runs \
        --epochs 100
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

from ultralytics import YOLO

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
)
logger = logging.getLogger("TrainYOLO")


def find_last_checkpoint(project_dir: str, run_name: str) -> str | None:
    """
    Looks for a previous run's 'last.pt' checkpoint under the given project
    directory. If found, training should resume from it instead of starting
    over from the pretrained yolov8n.pt - this is what makes the pipeline
    survive a Colab disconnect without losing hours of progress.
    """
    checkpoint_path = Path(project_dir) / run_name / "weights" / "last.pt"
    if checkpoint_path.exists():
        logger.info("Found existing checkpoint: %s", checkpoint_path)
        return str(checkpoint_path)
    logger.info("No existing checkpoint found - starting fresh from pretrained weights.")
    return None


def train(
    data_yaml: str,
    project_dir: str,
    run_name: str = "animal_detector_v1",
    epochs: int = 100,
    batch_size: int = 16,
    image_size: int = 640,
    patience: int = 15,
) -> str:
    """
    Runs (or resumes) YOLOv8n fine-tuning on the custom dataset.

    Parameters
    ----------
    data_yaml : str
        Path to the dataset config YAML (paths to train/val images + class names).
    project_dir : str
        Root folder where run results/checkpoints are saved. MUST be on Google
        Drive in Colab so checkpoints survive a disconnect.
    run_name : str
        Subfolder name for this training run - reused on resume so it finds
        the same checkpoint.
    epochs : int
        Max training epochs. With early stopping (patience), it may finish sooner.
    batch_size : int
        Lower this (e.g. 8) if you hit CUDA out-of-memory errors on free-tier GPU.
    image_size : int
        Input resolution. 640 is YOLO's standard; smaller (e.g. 416) trains
        faster on weaker hardware at a small accuracy cost.
    patience : int
        Stops training early if validation performance doesn't improve for
        this many epochs - avoids wasting free-tier compute hours on a
        plateaued model.

    Returns
    -------
    str
        Path to the best-performing checkpoint (best.pt) from this run.
    """
    existing_checkpoint = find_last_checkpoint(project_dir, run_name)

    # If a checkpoint exists, resume FROM it. Otherwise start from the
    # pretrained COCO weights (transfer learning starting point).
    model = YOLO(existing_checkpoint if existing_checkpoint else "yolov8n.pt")

    logger.info(
        "Starting training: epochs=%d batch=%d imgsz=%d patience=%d resume=%s",
        epochs, batch_size, image_size, patience, bool(existing_checkpoint),
    )

    try:
        model.train(
            data=data_yaml,
            epochs=epochs,
            batch=batch_size,
            imgsz=image_size,
            patience=patience,
            project=project_dir,
            name=run_name,
            exist_ok=True,          # allows resuming into the same run folder
            resume=bool(existing_checkpoint),
            save=True,              # writes last.pt every epoch, best.pt on improvement
            save_period=1,          # checkpoint every epoch - critical for free-tier disconnects
            device=0,               # GPU if available; Ultralytics auto-falls back to CPU
            workers=2,              # conservative for Colab free-tier CPU core limits
            verbose=True,
        )
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Training interrupted: %s. If this was a disconnect, simply re-run "
            "this script with the same --project and --name; it will resume "
            "automatically from the last saved checkpoint.",
            exc,
        )
        raise

    best_checkpoint = Path(project_dir) / run_name / "weights" / "best.pt"
    logger.info("Training complete. Best checkpoint saved at: %s", best_checkpoint)
    return str(best_checkpoint)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fine-tune YOLOv8n on custom animal dataset")
    parser.add_argument("--data", type=str, required=True, help="Path to data.yaml")
    parser.add_argument("--project", type=str, required=True, help="Drive path for checkpoints/results")
    parser.add_argument("--name", type=str, default="animal_detector_v1")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch", type=int, default=16)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--patience", type=int, default=15)
    args = parser.parse_args()

    train(
        data_yaml=args.data,
        project_dir=args.project,
        run_name=args.name,
        epochs=args.epochs,
        batch_size=args.batch,
        image_size=args.imgsz,
        patience=args.patience,
    )
