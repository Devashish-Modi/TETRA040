# Animal Detection System — ML Lead Package (Phases 4–6)

## Are the phases connected? Yes — each one's OUTPUT is the next one's REQUIRED INPUT.

This isn't a set of separate unrelated scripts — it's one pipeline, built in stages.
Nothing in Phase 5 or 6 works without what the previous phase actually produced.
Here's exactly how they chain together:

```
┌─────────────────────┐
│  PHASE 4             │  Input:  datasets/raw/<class_name>/*.jpg  (images YOU collect)
│  dataset_preparation │
│  .py                 │  Output: datasets/organized/
│                      │           ├── images/train, images/val, images/test
│                      │           ├── labels/train, labels/val, labels/test  (empty so far)
│                      │           └── class_names.json   <-- critical link to Phase 5 & 6
└─────────┬────────────┘
          │ produces the exact folder structure + class order Phase 5 expects
          ▼
┌──────────────────────┐
│  PHASE 5              │  Input:  datasets/organized/  (from Phase 4)
│  annotation_validator │           + your manually-created label .txt files
│  .py                  │           (using class_names.json's exact order)
│                       │  Output: validated labels/train, labels/val, labels/test
└─────────┬─────────────┘
          │ guarantees labels are well-formed BEFORE training wastes compute on them
          ▼
┌──────────────────┐
│  PHASE 6          │  Input:  data.yaml  (points to Phase 4's folders +
│  train_yolo.py    │           Phase 5's validated labels + class list)
│                   │  Output: best.pt  (your trained model weights)
└─────────┬─────────┘
          │ best.pt is what Phase 7/8/9 will load to actually run detection
          ▼
   [ Phase 7: Camera Integration  -> feeds frames in ]
   [ Phase 8: Object Detection    -> runs best.pt on those frames ]
   [ Phase 9: Multi-Object Tracking -> assigns IDs across frames ]
```

### The critical thread: `class_names.json` / `data.yaml`'s `names` list

Phase 4 generates `class_names.json` from your raw folder names.
Phase 5's validator uses that exact same list to check every label's `class_id` is valid.
Phase 6's `data.yaml` `names:` list must match that same order exactly.

**If these three ever disagree on order, the model doesn't error out — it just
silently learns the wrong species for each class_id.** This is why Phase 4/5/6
were built to explicitly reference each other's output rather than each
assuming its own class list.

### What is NOT yet connected

**`camera_test.py` and `yolo_webcam_demo.py`** (in `extra_demos/`) are standalone
sanity-check tools, not official numbered phases. They use a generic pretrained
COCO model, not your `best.pt` from Phase 6. Once Phase 8 (Object Detection) is
built, it will load your actual trained model (`best.pt`) instead of the
pretrained demo weights — that's when the "camera → your model → your 16
species" pipeline becomes fully real.

---

## Folder contents

```
ml_lead_phases/
├── dataset_preparation.py       # Phase 4
├── annotation_validator.py      # Phase 5
├── train_yolo.py                # Phase 6
├── data.yaml                    # Phase 6 config (shared by Phase 6 training)
└── tests/
    ├── test_dataset_preparation.py
    └── test_annotation_validator.py

extra_demos/
├── camera_test.py                # Standalone webcam sanity check (not a numbered phase)
└── yolo_webcam_demo.py           # Standalone pretrained-model demo (not a numbered phase)
```

## Recommended run order (once you have real data)

1. Populate `datasets/raw/<class>/*.jpg` with your collected images
2. `python dataset_preparation.py` → builds `datasets/organized/`
3. Annotate images (LabelImg/CVAT/Roboflow) into `datasets/organized/labels/...`
4. `python annotation_validator.py` → confirms labels are clean
5. Edit `data.yaml` paths if needed, then `python train_yolo.py --data data.yaml --project <drive_path>`
6. `pytest tests/ -v` any time to sanity-check the code logic itself with synthetic data

## Phases remaining (not yet built)
- Phase 7 — Camera Integration
- Phase 8 — Object Detection (this is where `best.pt` finally gets loaded live)
- Phase 9 — Multi-Object Tracking
