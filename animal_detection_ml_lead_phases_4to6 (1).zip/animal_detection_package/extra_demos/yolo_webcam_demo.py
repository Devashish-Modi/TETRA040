"""
yolo_webcam_demo.py

Quick demo: runs a FREE, pretrained YOLOv8n model (trained on COCO) against
either (a) your laptop webcam feed in real time, or (b) a single uploaded
photo.

Every detection is stored in ONE variable, `detection_log` - a list of
dictionaries with type, confidence, and timestamp - and printed as a summary
table at the end. This mirrors the project's eventual database schema
(Detections table).

This is NOT your final custom model - COCO's pretrained classes only cover
a subset of your target species: person, dog, cat, cow, horse, sheep, bird.
Species like buffalo, camel, tiger, leopard, elephant, snake etc. are NOT in
COCO and will only be detected correctly after Phase 6 (custom training on
your own annotated dataset).

Purpose: prove the "image/camera -> model -> bounding boxes" pipeline works
end to end on your laptop, RIGHT NOW, using zero custom training.

Run (webcam mode - default):
    pip install ultralytics opencv-python --break-system-packages
    python yolo_webcam_demo.py

Run (photo mode):
    python yolo_webcam_demo.py --image path/to/your/photo.jpg

Controls (webcam mode):
    Press 'q' to quit.
"""

import argparse
import logging
from datetime import datetime
from pathlib import Path

import cv2
from ultralytics import YOLO

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s")
logger = logging.getLogger("YoloWebcamDemo")

# Classes from COCO that overlap with this project's target species.
# Everything else COCO detects (car, chair, laptop, etc.) will be filtered out
# so the demo stays focused on what this project actually cares about.
#
# IMPORTANT: COCO's 80 classes do NOT include pig, goat, buffalo, camel, tiger,
# lion, leopard, monkey, deer, or snake - these will ONLY be detected after
# Phase 6 (custom training on your own annotated dataset). No configuration
# change here can add species that were never in the pretrained model's
# training data.
RELEVANT_CLASSES = {"person", "dog", "cat", "cow", "horse", "sheep", "bird", "elephant", "bear"}


def run_demo(camera_index: int = 0, confidence_threshold: float = 0.5) -> list:
    """
    Loads pretrained YOLOv8n (auto-downloads ~6MB weights on first run - this
    is free, no API key needed) and runs live inference on the webcam feed.

    Every detection is recorded into ONE variable, `detection_log` - a list of
    dictionaries, each holding the detected type, its confidence, and the
    exact timestamp it was seen. This mirrors the project's eventual database
    schema (Detections table: type, confidence, timestamp, camera source).

    Parameters
    ----------
    camera_index : int
        0 = default laptop webcam.
    confidence_threshold : float
        Detections below this confidence are hidden, to avoid flooding the
        screen with low-quality guesses.

    Returns
    -------
    list of dict
        detection_log - every detection recorded during this session.
    """
    logger.info("Loading pretrained YOLOv8n model (downloads automatically if not cached)...")
    model = YOLO("yolov8n.pt")  # nano version - fastest, CPU-friendly, ideal for laptop/free-tier

    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        logger.error("Could not open camera at index %d.", camera_index)
        return []

    logger.info("Camera opened. Starting detection loop - press 'q' to quit.")

    # THE single variable holding all detections for this session.
    detection_log: list = []

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                logger.warning("Failed to read frame - stopping.")
                break

            # verbose=False keeps the console clean; conf filters weak detections early
            results = model.predict(frame, conf=confidence_threshold, verbose=False)

            for result in results:
                for box in result.boxes:
                    class_id = int(box.cls[0])
                    class_name = model.names[class_id]

                    if class_name not in RELEVANT_CLASSES:
                        continue  # skip irrelevant COCO classes (car, chair, etc.)

                    confidence = float(box.conf[0])
                    x1, y1, x2, y2 = map(int, box.xyxy[0])

                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    label = f"{class_name} {confidence:.2f}"
                    cv2.putText(
                        frame, label, (x1, max(y1 - 10, 0)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2,
                    )

                    # Record this detection: type, confidence, and the moment it happened.
                    detection_log.append({
                        "type": class_name,
                        "confidence": round(confidence, 4),
                        "timestamp": datetime.now().isoformat(timespec="seconds"),
                    })

            cv2.imshow("YOLOv8n Pretrained Demo (COCO classes only)", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
    finally:
        cap.release()
        cv2.destroyAllWindows()
        logger.info("Demo ended. Total detections recorded: %d", len(detection_log))
        print_detection_log(detection_log)

    return detection_log


def print_detection_log(detection_log: list) -> None:
    """
    Prints the detection_log variable in a clean, readable table.
    Takes the single list-of-dicts variable produced by run_demo() or
    run_on_image() and displays type, confidence, and timestamp for each entry.
    """
    if not detection_log:
        print("\nNo detections were recorded.")
        return

    print("\n=== Detection Log ===")
    print(f"{'Timestamp':<20} {'Type':<10} {'Confidence':<10}")
    print("-" * 42)
    for entry in detection_log:
        print(f"{entry['timestamp']:<20} {entry['type']:<10} {entry['confidence']:<10}")
    print(f"\nTotal detections: {len(detection_log)}")


def run_on_image(image_path: str, confidence_threshold: float = 0.5) -> list:
    """
    Runs detection on a single uploaded photo instead of a live camera feed.
    Displays the result in a window and also saves an annotated copy to disk
    so you have something to show/share without needing a screenshot.

    Every detection is recorded into ONE variable, `detection_log` - a list of
    dictionaries, each holding the detected type, its confidence, and the
    timestamp the detection was made.

    Parameters
    ----------
    image_path : str
        Path to the photo you want to test (jpg/png/etc).
    confidence_threshold : float
        Detections below this confidence are hidden.

    Returns
    -------
    list of dict
        detection_log - every detection found in this image.
    """
    image_path_obj = Path(image_path)
    if not image_path_obj.exists():
        logger.error("Image file not found: %s", image_path)
        return []

    frame = cv2.imread(str(image_path_obj))
    if frame is None:
        logger.error("Could not read image (corrupt or unsupported format): %s", image_path)
        return []

    logger.info("Loading pretrained YOLOv8n model (downloads automatically if not cached)...")
    model = YOLO("yolov8n.pt")

    results = model.predict(frame, conf=confidence_threshold, verbose=False)

    # THE single variable holding all detections found in this image.
    detection_log: list = []

    for result in results:
        for box in result.boxes:
            class_id = int(box.cls[0])
            class_name = model.names[class_id]

            if class_name not in RELEVANT_CLASSES:
                continue  # skip irrelevant COCO classes (car, chair, etc.)

            confidence = float(box.conf[0])
            x1, y1, x2, y2 = map(int, box.xyxy[0])

            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            label = f"{class_name} {confidence:.2f}"
            cv2.putText(
                frame, label, (x1, max(y1 - 10, 0)),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2,
            )

            # Record this detection: type, confidence, and the moment it was found.
            detection_log.append({
                "type": class_name,
                "confidence": round(confidence, 4),
                "timestamp": datetime.now().isoformat(timespec="seconds"),
            })

    if detection_log:
        logger.info("Detected %d object(s) in image.", len(detection_log))
    else:
        logger.info(
            "No known animal/human detected in this image (either it's not one of "
            "%s, or it's a species outside COCO's classes that needs Phase 6's "
            "custom-trained model).",
            sorted(RELEVANT_CLASSES),
        )

    output_path = image_path_obj.parent / f"{image_path_obj.stem}_detected{image_path_obj.suffix}"
    cv2.imwrite(str(output_path), frame)
    logger.info("Annotated image saved to: %s", output_path)

    print_detection_log(detection_log)

    cv2.imshow("YOLOv8n Pretrained Demo - Photo Mode (press any key to close)", frame)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    return detection_log


def run_on_video(video_path: str, confidence_threshold: float = 0.5, save_output: bool = True) -> list:
    """
    Runs detection on a recorded video file (mp4, avi, mov, etc.) instead of
    a live camera feed. Same detection logic as run_demo(), just reading
    frames from a file instead of a camera device - cv2.VideoCapture handles
    both identically, which is exactly why the master prompt requires the
    pipeline work the same way "for every input source."

    Every detection across every frame is recorded into ONE variable,
    `detection_log`, and printed as a summary table at the end.

    Parameters
    ----------
    video_path : str
        Path to the video file to process.
    confidence_threshold : float
        Detections below this confidence are hidden.
    save_output : bool
        If True, saves an annotated copy of the video (with boxes drawn) next
        to the original file, so you have a shareable result.

    Returns
    -------
    list of dict
        detection_log - every detection recorded across the whole video.
    """
    video_path_obj = Path(video_path)
    if not video_path_obj.exists():
        logger.error("Video file not found: %s", video_path)
        return []

    cap = cv2.VideoCapture(str(video_path_obj))
    if not cap.isOpened():
        logger.error("Could not open video (corrupt or unsupported format): %s", video_path)
        return []

    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    logger.info("Video opened: %dx%d, %.1f FPS, %d frames", width, height, fps, total_frames)

    logger.info("Loading pretrained YOLOv8n model (downloads automatically if not cached)...")
    model = YOLO("yolov8n.pt")

    writer = None
    if save_output:
        output_path = video_path_obj.parent / f"{video_path_obj.stem}_detected.mp4"
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(output_path), fourcc, fps, (width, height))

    # THE single variable holding all detections found across the whole video.
    detection_log: list = []
    frame_number = 0

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break  # end of video reached

            frame_number += 1
            results = model.predict(frame, conf=confidence_threshold, verbose=False)

            for result in results:
                for box in result.boxes:
                    class_id = int(box.cls[0])
                    class_name = model.names[class_id]

                    if class_name not in RELEVANT_CLASSES:
                        continue

                    confidence = float(box.conf[0])
                    x1, y1, x2, y2 = map(int, box.xyxy[0])

                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    label = f"{class_name} {confidence:.2f}"
                    cv2.putText(
                        frame, label, (x1, max(y1 - 10, 0)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2,
                    )

                    detection_log.append({
                        "type": class_name,
                        "confidence": round(confidence, 4),
                        "timestamp": datetime.now().isoformat(timespec="seconds"),
                        "frame": frame_number,
                    })

            if writer is not None:
                writer.write(frame)

            cv2.imshow("YOLOv8n Pretrained Demo - Video Mode (press 'q' to stop early)", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                logger.info("Stopped early by user at frame %d/%d.", frame_number, total_frames)
                break
    finally:
        cap.release()
        if writer is not None:
            writer.release()
            logger.info("Annotated video saved to: %s", output_path)
        cv2.destroyAllWindows()
        logger.info("Video processing ended. Total detections recorded: %d", len(detection_log))
        print_detection_log(detection_log)

    return detection_log


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="YOLOv8n pretrained detection demo")
    parser.add_argument(
        "--image", type=str, default=None,
        help="Path to a photo to run detection on. If omitted, an interactive menu appears.",
    )
    parser.add_argument(
        "--video", type=str, default=None,
        help="Path to a video file to run detection on.",
    )
    args = parser.parse_args()

    if args.image:
        run_on_image(image_path=args.image)
    elif args.video:
        run_on_video(video_path=args.video)
    else:
        # No flag passed - show an interactive menu instead of silently defaulting
        # to webcam, so it's impossible to end up in the wrong mode by accident.
        # flush=True forces immediate display - without it, some terminals/IDEs
        # buffer print() output and it can appear AFTER the input() prompt,
        # making the menu look like it "didn't show."
        print("\n=== YOLOv8n Detection Demo ===", flush=True)
        print("1. Use laptop webcam (live)", flush=True)
        print("2. Upload / test a photo", flush=True)
        print("3. Upload / test a recorded video", flush=True)
        choice = input("Choose an option (1, 2, or 3): ").strip()

        if choice == "2":
            image_path = input("Enter the full path to your photo: ").strip().strip('"')
            run_on_image(image_path=image_path)
        elif choice == "3":
            video_path = input("Enter the full path to your video: ").strip().strip('"')
            run_on_video(video_path=video_path)
        elif choice == "1":
            run_demo(camera_index=0)
        else:
            print("Invalid choice. Please enter 1, 2, or 3. Exiting.", flush=True)
